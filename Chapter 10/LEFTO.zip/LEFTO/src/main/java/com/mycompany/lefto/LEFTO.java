/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lefto;

/**
 *
 * @author Ideapad Slim 3
 */
public class LEFTO {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
