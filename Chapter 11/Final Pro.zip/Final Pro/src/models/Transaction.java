package models;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.List;
/**
 *
 * @author Ideapad Slim 3
 */
public class Transaction {
    public String transactionId; // Unique identifier for the transaction
    public String dateTime; // Date and time of the transaction
    public List<CartItem> items; // List of items purchased
    public double shippingFee; // Shipping fee for the transaction
    public double discount; // Discount applied
    public double vat; // VAT applied
    public double total; // Total amount for the transaction

    // Constructor
    public Transaction(String transactionId, String dateTime, List<CartItem> items, double shippingFee, double discount, double vat, double total) {
        this.transactionId = transactionId;
        this.dateTime = dateTime;
        this.items = items;
        this.shippingFee = shippingFee;
        this.discount = discount;
        this.vat = vat;
        this.total = total;
    }

    // Getters and Setters
    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    public List<CartItem> getItems() {
        return items;
    }

    public void setItems(List<CartItem> items) {
        this.items = items;
    }

    public double getShippingFee() {
        return shippingFee;
    }

    public void setShippingFee(double shippingFee) {
        this.shippingFee = shippingFee;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

    public double getVat() {
        return vat;
    }

    public void setVat(double vat) {
        this.vat = vat;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    @Override
    public String toString() {
        return "Transaction{" +
                "transactionId='" + transactionId + '\'' +
                ", dateTime='" + dateTime + '\'' +
                ", items=" + items +
                ", shippingFee=" + shippingFee +
                ", discount=" + discount +
                ", vat=" + vat +
                ", total=" + total +
                '}';
    }
}
